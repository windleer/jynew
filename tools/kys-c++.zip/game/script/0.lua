
for i=0,199 do
--additemwithouthint(i,65536);
end

setRoleMagic(0,0,1,900)

