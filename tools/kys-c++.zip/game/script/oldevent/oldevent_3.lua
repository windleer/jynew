--function oldevent_3()
    instruct_1(23,1,0);   --  1(1):[胡斐]说: 可恨啊！可恨！*只恨胡某刀谱不全，*未能练成我祖传之胡家刀法
    instruct_0();   --  0(0)::空语句(清屏)
    --talk(1,0,'hello早','倫納德');
--end

